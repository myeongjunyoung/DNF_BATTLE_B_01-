<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <title>던전앤파이터 전투 시스템</title>
  <style>
    * { box-sizing: border-box; }
    body {
      font-family: 'Malgun Gothic', 'Segoe UI', sans-serif;
      background: radial-gradient(circle at top, #2b1055, #1a1a2e 60%, #0d0d1a);
      color: #eaeaea;
      margin: 0;
      min-height: 100vh;
      padding: 60px 40px;
    }
    .wrapper { max-width: 880px; margin: 0 auto; }
    .hero {
      text-align: center;
      padding: 40px 24px;
      background: linear-gradient(135deg, rgba(255,215,0,0.08), rgba(255,107,107,0.05));
      border: 1px solid rgba(255,215,0,0.25);
      border-radius: 16px;
      box-shadow: 0 12px 40px rgba(0,0,0,0.45);
    }
    .hero h1 {
      margin: 0 0 8px;
      font-size: 36px;
      color: #ffd700;
      letter-spacing: 2px;
      text-shadow: 0 0 18px rgba(255,215,0,0.35);
    }
    .hero .subtitle { margin: 0; color: #c9c9d6; font-size: 14px; }

    .menu {
      margin-top: 36px;
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
      gap: 16px;
    }
    .menu a {
      display: block;
      padding: 22px 24px;
      background: linear-gradient(135deg, #4a4e69, #2e2f4a);
      color: #fff;
      text-decoration: none;
      border-radius: 12px;
      border: 1px solid rgba(255,255,255,0.06);
      transition: transform .15s ease, box-shadow .15s ease, background .2s ease;
    }
    .menu a:hover {
      transform: translateY(-2px);
      background: linear-gradient(135deg, #5d6188, #3a3c5e);
      box-shadow: 0 10px 24px rgba(0,0,0,0.5);
    }
    .menu a .label { font-size: 18px; font-weight: bold; display: block; }
    .menu a .desc { font-size: 13px; color: #c9c9d6; margin-top: 6px; display: block; }

    .info {
      margin-top: 28px;
      padding: 20px 24px;
      background: rgba(22, 33, 62, 0.7);
      border-left: 4px solid #ffd700;
      border-radius: 8px;
    }
    .info ol { margin: 8px 0 0; padding-left: 22px; line-height: 1.8; }
    .info strong { color: #ffd700; letter-spacing: 1px; }
  </style>
</head>
<body>
  <div class="wrapper">
    <div class="hero">
      <h1>DUNGEON &amp; FIGHTER</h1>
      <p class="subtitle">미니 전투 시스템 · DnF_Battle_B_01팀</p>
    </div>

    <div class="menu">
      <a href="캐릭터생성.jsp">
        <span class="label">캐릭터 생성</span>
        <span class="desc">전사 또는 마법사를 만들어 출전합니다</span>
      </a>
      <a href="몬스터공격.jsp">
        <span class="label">보스 레이드</span>
        <span class="desc">보스에게 스킬을 사용하여 처치하세요</span>
      </a>
    </div>

    <div class="info">
      <strong>진행 안내</strong>
      <ol>
        <li>캐릭터 생성 (플레이어id는 "hero")</li>
        <li>보스를 소환하고 스킬로 데미지를 누적</li>
        <li>보스 HP가 0이 되면 클리어</li>
      </ol>
    </div>
  </div>
</body>
</html>
