<%@ page contentType="text/html;charset=UTF-8" language="java" pageEncoding="UTF-8" %>
<%@ page import="dnf.service.전투" %>
<%@ page import="dnf.model.캐릭터" %>
<%
  String 플레이어id = request.getParameter("플레이어id");
  String 캐릭터명 = request.getParameter("캐릭터명");
  String 직업 = request.getParameter("직업");
  String 레벨문자열 = request.getParameter("레벨");

  boolean 제출됨 = 플레이어id != null;
  String 결과메시지 = null;
  캐릭터 생성된캐릭터 = null;

  if (제출됨) {
    try {
      int 레벨 = Integer.parseInt(레벨문자열);
      전투 전투서비스 = (전투) session.getAttribute("battle");
      if (전투서비스 == null) {
        전투서비스 = new 전투();
      }
      생성된캐릭터 = 전투서비스.캐릭터생성(플레이어id, 캐릭터명, 직업, 레벨);
      if (생성된캐릭터 == null) {
        결과메시지 = "오류: 플레이어 인증 실패 또는 잘못된 직업입니다.";
      } else {
        session.setAttribute("battle", 전투서비스);
        결과메시지 = "캐릭터 생성 성공";
      }
    } catch (NumberFormatException e) {
      결과메시지 = "오류: 레벨은 숫자여야 합니다.";
    }
  }

  String 입력플레이어id = 플레이어id != null ? 플레이어id : "";
  String 입력캐릭터명 = 캐릭터명 != null ? 캐릭터명 : "";
  String 선택직업 = 직업 != null ? 직업 : "전사";
  String 입력레벨 = 레벨문자열 != null ? 레벨문자열 : "";
%>
<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <title>캐릭터 생성 - Create_Character_UI</title>
  <style>
    * { box-sizing: border-box; }
    body {
      font-family: 'Malgun Gothic', 'Segoe UI', sans-serif;
      background: radial-gradient(circle at top, #2b1055, #1a1a2e 60%, #0d0d1a);
      color: #eaeaea;
      margin: 0;
      min-height: 100vh;
      padding: 48px 40px;
    }
    .wrapper { max-width: 720px; margin: 0 auto; }
    .topbar { margin-bottom: 24px; }
    .topbar a {
      color: #ffd700;
      text-decoration: none;
      margin-right: 16px;
      font-size: 14px;
    }
    .topbar a:hover { text-decoration: underline; }

    h1 {
      margin: 0 0 24px;
      color: #ffd700;
      letter-spacing: 2px;
      text-shadow: 0 0 12px rgba(255,215,0,0.25);
    }

    form {
      background: linear-gradient(135deg, rgba(22,33,62,0.95), rgba(30,30,60,0.95));
      padding: 28px 32px;
      border-radius: 14px;
      border: 1px solid rgba(255,215,0,0.15);
      box-shadow: 0 12px 30px rgba(0,0,0,0.5);
    }
    label {
      display: block;
      margin-top: 14px;
      font-size: 13px;
      color: #c9c9d6;
      letter-spacing: 0.5px;
    }
    input, select {
      width: 100%;
      padding: 10px 12px;
      margin-top: 6px;
      background: #0f1530;
      color: #eaeaea;
      border: 1px solid rgba(255,255,255,0.12);
      border-radius: 6px;
      font-size: 15px;
      outline: none;
      transition: border-color .15s ease, box-shadow .15s ease;
    }
    input:focus, select:focus {
      border-color: #ffd700;
      box-shadow: 0 0 0 3px rgba(255,215,0,0.15);
    }
    button {
      margin-top: 22px;
      padding: 12px 24px;
      background: linear-gradient(135deg, #ffd700, #f5a623);
      border: none;
      cursor: pointer;
      font-weight: bold;
      color: #1a1a2e;
      border-radius: 6px;
      font-size: 15px;
      letter-spacing: 1px;
      transition: transform .15s ease, box-shadow .15s ease;
    }
    button:hover {
      transform: translateY(-1px);
      box-shadow: 0 8px 18px rgba(255,215,0,0.25);
    }

    .result {
      margin-top: 28px;
      padding: 20px 24px;
      border-radius: 10px;
      box-shadow: 0 6px 20px rgba(0,0,0,0.35);
    }
    .result h3 { margin: 0 0 8px; }
    .success {
      background: linear-gradient(135deg, #244d1f, #1a3614);
      border-left: 4px solid #7cb342;
    }
    .error {
      background: linear-gradient(135deg, #4a1a1a, #321010);
      border-left: 4px solid #e57373;
    }
    .info {
      background: rgba(15, 21, 48, 0.7);
      padding: 14px 16px;
      margin-top: 12px;
      border-radius: 6px;
      line-height: 1.7;
    }
    .next-link {
      display: inline-block;
      margin-top: 12px;
      color: #ffd700;
      text-decoration: none;
      font-weight: bold;
    }
    .next-link:hover { text-decoration: underline; }
  </style>
</head>
<body>
  <div class="wrapper">
    <div class="topbar">
      <a href="index.jsp">← 메인으로</a>
      <a href="몬스터공격.jsp">보스 레이드 →</a>
    </div>

    <h1>캐릭터 생성</h1>

    <form method="post" action="캐릭터생성.jsp">
      <label>플레이어id
        <input type="text" name="플레이어id" value="<%= 입력플레이어id %>" required>
      </label>
      <label>캐릭터명
        <input type="text" name="캐릭터명" value="<%= 입력캐릭터명 %>" required>
      </label>
      <label>직업
        <select name="직업">
          <option value="전사" <%= "전사".equals(선택직업) ? "selected" : "" %>>전사</option>
          <option value="마법사" <%= "마법사".equals(선택직업) ? "selected" : "" %>>마법사</option>
        </select>
      </label>
      <label>레벨
        <input type="number" name="레벨" value="<%= 입력레벨 %>" min="1" required>
      </label>
      <button type="submit">캐릭터 생성</button>
    </form>

    <% if (제출됨) { %>
      <div class="result <%= 생성된캐릭터 != null ? "success" : "error" %>">
        <h3><%= 결과메시지 %></h3>
        <% if (생성된캐릭터 != null) { %>
          <div class="info">
            <strong>생성된 캐릭터 정보</strong><br>
            캐릭터명: <%= 생성된캐릭터.get캐릭터명() %><br>
            직업: <%= 생성된캐릭터.get직업() %><br>
            레벨: <%= 생성된캐릭터.get레벨() %><br>
            HP: <%= 생성된캐릭터.getHP() %><br>
            공격력: <%= 생성된캐릭터.get공격력() %>
          </div>
          <a class="next-link" href="몬스터공격.jsp">→ 보스 레이드 시작하기</a>
        <% } %>
      </div>
    <% } %>
  </div>
</body>
</html>
