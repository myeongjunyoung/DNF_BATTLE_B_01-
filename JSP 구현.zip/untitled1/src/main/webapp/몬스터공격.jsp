<%@ page contentType="text/html;charset=UTF-8" language="java" pageEncoding="UTF-8" %>
<%@ page import="dnf.service.전투" %>
<%@ page import="dnf.model.캐릭터" %>
<%@ page import="dnf.model.보스" %>
<%
  전투 전투서비스 = (전투) session.getAttribute("battle");
  캐릭터 보관된캐릭터 = (전투서비스 != null) ? 전투서비스.get캐릭터() : null;
  보스 현재보스 = (전투서비스 != null) ? 전투서비스.get보스() : null;

  String 액션 = request.getParameter("action");
  String 입력플레이어id = request.getParameter("플레이어id");
  String 입력보스명 = request.getParameter("보스명");
  String 입력보스HP = request.getParameter("보스HP");

  String 결과메시지 = null;
  boolean 공격성공 = false;
  boolean 클리어 = false;
  double 마지막데미지 = 0;
  String 마지막등급 = null;

  if (전투서비스 != null && "소환".equals(액션)) {
    int 보스HP값 = 1000;
    try {
      if (입력보스HP != null && !입력보스HP.trim().isEmpty()) {
        보스HP값 = Integer.parseInt(입력보스HP);
      }
    } catch (NumberFormatException ignored) {}
    현재보스 = 전투서비스.보스소환(입력플레이어id, 입력보스명, 보스HP값);
    if (현재보스 == null) {
      결과메시지 = "오류: 플레이어 인증 실패 또는 캐릭터가 없습니다.";
    }
  } else if (전투서비스 != null && "재도전".equals(액션)) {
    전투서비스.보스초기화();
    현재보스 = null;
  } else if (전투서비스 != null && "공격".equals(액션)) {
    if (현재보스 == null) {
      결과메시지 = "보스를 먼저 소환하세요.";
    } else {
      String 응답 = 전투서비스.보스공격();
      if ("NOT_AUTH".equals(응답)) {
        결과메시지 = "오류: 인증되지 않은 세션입니다. 보스를 다시 소환하세요.";
      } else if ("FAIL".equals(응답)) {
        결과메시지 = "오류: 캐릭터 또는 보스가 없습니다.";
      } else if ("ALREADY_DEFEATED".equals(응답)) {
        결과메시지 = "이미 처치된 보스입니다. 재도전을 눌러주세요.";
      } else {
        int 구분자 = 응답.indexOf('|');
        String 상태 = 응답.substring(0, 구분자);
        String 본문 = 응답.substring(구분자 + 1);
        공격성공 = true;
        클리어 = "CLEAR".equals(상태);
        결과메시지 = 본문;
        try {
          String[] parts = 본문.split(",");
          마지막데미지 = Double.parseDouble(parts[0].substring(parts[0].indexOf(':') + 1));
          마지막등급 = parts[1].substring(parts[1].indexOf(':') + 1);
        } catch (Exception ignored) {}
      }
    }
  }

  String id값 = 입력플레이어id != null ? 입력플레이어id : "";
  String 보스명값 = 입력보스명 != null ? 입력보스명 : "";
  String 보스HP값표시 = 입력보스HP != null ? 입력보스HP : "";
%>
<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <title>보스 레이드 - Attack_Monster_UI</title>
  <style>
    * { box-sizing: border-box; }
    body {
      font-family: 'Malgun Gothic', 'Segoe UI', sans-serif;
      background: radial-gradient(circle at top, #3d0e1a, #1a1a2e 60%, #0d0d1a);
      color: #eaeaea;
      margin: 0;
      min-height: 100vh;
      padding: 48px 40px;
    }
    .wrapper { max-width: 820px; margin: 0 auto; }
    .topbar { margin-bottom: 24px; }
    .topbar a {
      color: #ffd700;
      text-decoration: none;
      margin-right: 16px;
      font-size: 14px;
    }
    .topbar a:hover { text-decoration: underline; }

    h1 {
      margin: 0 0 24px;
      color: #ff6b6b;
      letter-spacing: 2px;
      text-shadow: 0 0 14px rgba(255,107,107,0.3);
    }
    h2 { margin: 0 0 12px; color: #ffd700; letter-spacing: 1px; }

    .card {
      background: linear-gradient(135deg, rgba(22,33,62,0.95), rgba(30,18,40,0.95));
      padding: 24px 28px;
      border-radius: 14px;
      border: 1px solid rgba(255,107,107,0.15);
      box-shadow: 0 12px 30px rgba(0,0,0,0.5);
      margin-bottom: 22px;
    }

    .char-panel { display: grid; grid-template-columns: repeat(auto-fit, minmax(120px, 1fr)); gap: 12px; }
    .stat {
      background: rgba(15,21,48,0.7);
      padding: 12px 14px;
      border-radius: 8px;
      border-left: 3px solid #ffd700;
    }
    .stat .k { display: block; font-size: 12px; color: #c9c9d6; }
    .stat .v { display: block; font-size: 18px; font-weight: bold; margin-top: 4px; }

    .boss-name {
      font-size: 22px;
      font-weight: bold;
      color: #ff6b6b;
      margin-bottom: 6px;
      letter-spacing: 1px;
    }
    .hp-row { display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px; font-size: 13px; color: #c9c9d6; }
    .hp-bar {
      width: 100%;
      height: 22px;
      background: rgba(15,21,48,0.8);
      border-radius: 11px;
      overflow: hidden;
      border: 1px solid rgba(255,255,255,0.08);
      position: relative;
    }
    .hp-fill {
      height: 100%;
      background: linear-gradient(90deg, #7cb342, #ffd54f 60%, #ff6b6b);
      transition: width .6s ease;
    }
    .hp-meta {
      margin-top: 10px;
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
      gap: 10px;
    }
    .hp-meta .stat .v { font-size: 16px; }

    form { display: flex; flex-wrap: wrap; gap: 12px; align-items: flex-end; }
    form label {
      flex: 1 1 180px;
      font-size: 13px;
      color: #c9c9d6;
    }
    input {
      width: 100%;
      padding: 10px 12px;
      margin-top: 6px;
      background: #0f1530;
      color: #eaeaea;
      border: 1px solid rgba(255,255,255,0.12);
      border-radius: 6px;
      font-size: 15px;
      outline: none;
      transition: border-color .15s ease, box-shadow .15s ease;
    }
    input:focus {
      border-color: #ff6b6b;
      box-shadow: 0 0 0 3px rgba(255,107,107,0.15);
    }
    button {
      padding: 12px 24px;
      border: none;
      cursor: pointer;
      font-weight: bold;
      border-radius: 6px;
      font-size: 15px;
      letter-spacing: 1px;
      transition: transform .15s ease, box-shadow .15s ease;
    }
    .btn-attack {
      background: linear-gradient(135deg, #ff6b6b, #c0392b);
      color: #fff;
    }
    .btn-summon {
      background: linear-gradient(135deg, #ffd700, #f5a623);
      color: #1a1a2e;
    }
    .btn-retry {
      background: linear-gradient(135deg, #4a4e69, #2e2f4a);
      color: #fff;
    }
    button:hover { transform: translateY(-1px); box-shadow: 0 8px 18px rgba(0,0,0,0.5); }

    .result {
      margin-top: 8px;
      padding: 18px 22px;
      border-radius: 10px;
    }
    .result h3 { margin: 0 0 6px; }
    .success { background: linear-gradient(135deg, #244d1f, #1a3614); border-left: 4px solid #7cb342; }
    .error   { background: linear-gradient(135deg, #4a1a1a, #321010); border-left: 4px solid #e57373; }
    .neutral { background: rgba(22,33,62,0.7); border-left: 4px solid #ffd700; }
    .damage-line { font-size: 18px; font-weight: bold; margin: 6px 0; }

    .clear-banner {
      text-align: center;
      padding: 30px 24px;
      background: linear-gradient(135deg, rgba(255,215,0,0.18), rgba(124,179,66,0.18));
      border: 2px solid #ffd700;
      border-radius: 14px;
      margin-bottom: 22px;
      box-shadow: 0 0 30px rgba(255,215,0,0.25);
    }
    .clear-banner .title {
      font-size: 38px;
      color: #ffd700;
      letter-spacing: 6px;
      text-shadow: 0 0 18px rgba(255,215,0,0.5);
      margin-bottom: 6px;
    }
    .clear-banner .sub { color: #f0e68c; font-size: 14px; }

    .warn {
      background: rgba(93, 74, 26, 0.65);
      padding: 18px 22px;
      border-left: 4px solid #ffd700;
      border-radius: 8px;
    }
  </style>
</head>
<body>
  <div class="wrapper">
    <div class="topbar">
      <a href="index.jsp">← 메인으로</a>
      <a href="캐릭터생성.jsp">캐릭터 생성</a>
    </div>

    <h1>보스 레이드</h1>

    <% if (전투서비스 == null || 보관된캐릭터 == null) { %>
      <div class="warn">
        세션에 캐릭터가 없습니다. <a href="캐릭터생성.jsp" style="color:#ffd700;">캐릭터 생성</a> 후 진행하세요.
      </div>
    <% } else { %>

      <div class="card">
        <h2>내 캐릭터</h2>
        <div class="char-panel">
          <div class="stat"><span class="k">캐릭터명</span><span class="v"><%= 보관된캐릭터.get캐릭터명() %></span></div>
          <div class="stat"><span class="k">직업</span><span class="v"><%= 보관된캐릭터.get직업() %></span></div>
          <div class="stat"><span class="k">레벨</span><span class="v"><%= 보관된캐릭터.get레벨() %></span></div>
          <div class="stat"><span class="k">HP</span><span class="v"><%= 보관된캐릭터.getHP() %></span></div>
          <div class="stat"><span class="k">공격력</span><span class="v"><%= 보관된캐릭터.get공격력() %></span></div>
        </div>
      </div>

      <% if (현재보스 == null) { %>
        <div class="card">
          <h2>보스 소환</h2>
          <p style="margin-top:0; color:#c9c9d6; font-size:14px;">출전 1회 인증 후 보스를 소환합니다. 이후 공격 시에는 추가 인증이 필요하지 않습니다.</p>
          <form method="post" action="몬스터공격.jsp">
            <input type="hidden" name="action" value="소환">
            <label>플레이어id (인증)
              <input type="text" name="플레이어id" value="<%= id값.isEmpty() ? "hero" : id값 %>" required>
            </label>
            <label>보스명
              <input type="text" name="보스명" value="<%= 보스명값.isEmpty() ? "어둠의 군주" : 보스명값 %>">
            </label>
            <label>보스 HP
              <input type="number" name="보스HP" value="<%= 보스HP값표시.isEmpty() ? "1000" : 보스HP값표시 %>" min="1">
            </label>
            <button class="btn-summon" type="submit">보스 소환</button>
          </form>
          <% if (결과메시지 != null) { %>
            <div class="result error" style="margin-top:18px;">
              <h3>오류</h3>
              <p><%= 결과메시지 %></p>
            </div>
          <% } %>
        </div>
      <% } else {
           double 비율 = 현재보스.getHP비율();
      %>
        <% if (현재보스.처치됨()) { %>
          <div class="clear-banner">
            <div class="title">VICTORY</div>
            <div class="sub"><%= 현재보스.get보스명() %> 처치 완료 · 공격 <%= 현재보스.get공격횟수() %>회 · 누적 데미지 <%= 현재보스.get누적데미지() %></div>
          </div>
        <% } %>

        <div class="card">
          <div class="boss-name">▼ <%= 현재보스.get보스명() %></div>
          <div class="hp-row">
            <span>HP</span>
            <span><%= 현재보스.get현재HP() %> / <%= 현재보스.get최대HP() %></span>
          </div>
          <div class="hp-bar">
            <div class="hp-fill" style="width: <%= 비율 %>%;"></div>
          </div>
          <div class="hp-meta">
            <div class="stat"><span class="k">누적 데미지</span><span class="v"><%= 현재보스.get누적데미지() %></span></div>
            <div class="stat"><span class="k">공격 횟수</span><span class="v"><%= 현재보스.get공격횟수() %></span></div>
            <div class="stat"><span class="k">남은 HP</span><span class="v"><%= 현재보스.get현재HP() %></span></div>
          </div>
        </div>

        <div class="card">
          <h2><%= 현재보스.처치됨() ? "보스 재도전" : "스킬 사용" %></h2>
          <% if (!현재보스.처치됨()) { %>
            <p style="margin-top:0; color:#c9c9d6; font-size:13px;">출전 인증 완료 · 추가 인증 없이 스킬을 시전합니다.</p>
            <form method="post" action="몬스터공격.jsp" style="margin-top:0;">
              <input type="hidden" name="action" value="공격">
              <button class="btn-attack" type="submit">
                <%= "전사".equals(보관된캐릭터.get직업()) ? "검 휘두르기" : "파이어볼" %> 시전
              </button>
            </form>
          <% } else { %>
            <form method="post" action="몬스터공격.jsp" style="margin-top:0;">
              <input type="hidden" name="action" value="재도전">
              <button class="btn-retry" type="submit">새 보스에 도전하기</button>
            </form>
          <% } %>
        </div>

        <% if (결과메시지 != null) { %>
          <div class="result <%= 공격성공 ? "success" : "error" %>">
            <h3><%= 클리어 ? "최후의 일격" : (공격성공 ? "공격 적중" : "오류") %></h3>
            <% if (공격성공) { %>
              <div class="damage-line">
                <%= "전사".equals(보관된캐릭터.get직업()) ? "검 휘두르기" : "파이어볼" %> ·
                데미지 <%= 마지막데미지 %> · <%= 마지막등급 %>
              </div>
              <div style="color:#c9c9d6; font-size:13px;">
                계산식: 공격력(<%= 보관된캐릭터.get공격력() %>) ×
                <%= "전사".equals(보관된캐릭터.get직업()) ? "1.5" : "2.0" %>
              </div>
            <% } else { %>
              <p><%= 결과메시지 %></p>
            <% } %>
          </div>
        <% } %>
      <% } %>
    <% } %>
  </div>
</body>
</html>
